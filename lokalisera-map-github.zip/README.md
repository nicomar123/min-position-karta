# Lokalisera mig – karta (GitHub Pages-ready)

En enkel Leaflet-karta som lokaliserar din position, visar markör + noggrannhetscirkel och kan följa dig kontinuerligt.

## 🚀 Snabbstart (GitHub Pages)
1. Skapa ett nytt repo på GitHub, t.ex. `lokalisera-map`.
2. Ladda upp alla filer i denna mapp till rooten av repot (eller `git push`).
3. Gå till **Settings → Pages** och välj:
   - **Source:** Deploy from a branch
   - **Branch:** `main` (root)
4. Öppna den publicerade länken (t.ex. `https://<ditt-användarnamn>.github.io/lokalisera-map/`).
5. Tillåt platstjänster i webbläsaren (HTTPS krävs – GitHub Pages fixar det).

## 📱 PWA (valfritt)
Appen har `manifest.webmanifest` och enkel `sw.js`, så du kan **Installera/“Lägg till på hemskärmen”**.
Obs: Endast appens egna filer cachas. Karttiles (OpenStreetMap via CDN) cachas inte i service workern.

## 🧭 Tips för bra noggrannhet
- Slå på **Exakt plats/Precise Location** (särskilt i iOS).
- Ha **Wi‑Fi på** för bättre hybridpositionering.
- Använd **Starta följning** för snabbare förbättring av position/accuracy.
- Gå nära fönster/utomhus för bättre GPS-sikt.

## 🧩 Anpassning
- Startvy (Vasastan) ändras i `index.html`: `setView([59.338, 18.038], 14)`.
- Byt bakgrundslager genom att ändra `L.tileLayer(...)`.
- Lägg till egna knappar/overlay-lager i samma fil.

## 🛠 Lokalt test
Kör en enkel server i mappen och öppna `http://localhost:8000`:
```bash
python -m http.server 8000
```

## Licens
OpenStreetMap-data © medverkande. Leaflet © upphovsrätt enligt deras licens.
